# Aegis · Endpoint Suite — proyecto completo

Proyecto WinUI 3 (.NET 8) montado sobre el **ZIP de Google Drive** (csproj, manifiestos,
assets y perfiles de publicación) + **los 12 archivos que pegaste** + los 8 que faltaban.

Namespace y ensamblado: **`AntivirusApp`**.

---

## 1. Credenciales de la pantalla de login

```
usuario:     admin
contraseña:  aegis
```

Se cambian creando `%LocalAppData%\Aegis\auth.json`:

```json
{ "user": "miUsuario", "sha256": "hash_sha256_de_la_contraseña_en_hex" }
```

`AuthService` no guarda la contraseña en claro y compara en tiempo fijo.

---

## 2. Archivos que pegaste (sin tocar su lógica)

| Archivo | Líneas |
|---|---|
| `App.xaml` | 104 |
| `App.xaml.cs` | 18 |
| `Services/NotificationService.cs` | 48 |
| `Views/ViewItems.cs` | 94 |
| `Views/LoginPage.xaml(.cs)` | 87 + 30 |
| `Views/ShellPage.xaml(.cs)` | 182 + 258 |
| `Views/ScanPage.xaml(.cs)` | 202 + 425 |
| `Views/LivePage.xaml(.cs)` | 152 + 180 |

## 3. Archivos que faltaban (escritos aquí, con las firmas exactas que usan los tuyos)

| Archivo | Contrato que respeta |
|---|---|
| `Models/Verdicts.cs` | `const string` `Malicious="M"`, `Suspicious="S"`, `Clean="C"`, `Error="E"` (los chips filtran por "M"/"S") |
| `Models/ScanMode.cs` | `Automatic`, `Quick`, `Folder`, `Deep` |
| `Models/ScanOptions.cs` | `new ScanOptions(ScanMode.Quick)` y `new ScanOptions(ScanMode.Folder, IncludeHidden: true)` |
| `Models/ScanResult.cs` | `Verdict`, `RiskScore`, `Reasons`, `Sha256`, `Size`, `Elapsed`, `IsError` — con `set` público (con `init` el build falla con CS8852 en `XamlTypeInfo.g.cs`) |
| `Engine/HeuristicScanner.cs` | `SafeScan(path, options, progress)`; acepta archivo o carpeta |
| `Engine/FileEnumerator.cs` | `Enumerate(folder, options, ct)` — lo usa `ScanPage.ScanFolderAsync` |
| `Engine/FolderWatcher.cs` | `new FolderWatcher(ruta)`, `FileDetected`, `WaitUntilReadyAsync` |
| `Engine/Ring.cs` | `Ring.Set(Ellipse, double)` mediante `StrokeDashArray` sobre la elipse rotada −90° |
| `Services/AuthService.cs` | `AuthService.Validate(usuario, contraseña)` |
| `MainWindow.xaml(.cs)` | `new MainWindow()` de `App.OnLaunched`: hospeda el `Frame` y navega a `LoginPage` |

## 4. Errores corregidos en tu código

Detectados compilando con Roslyn contra los ensamblados reales de WinUI:

| Error | Archivo | Causa | Corrección |
|---|---|---|---|
| `CS0103: FileEnumerator no existe` | `ScanPage.xaml.cs:101` | se usaba un tipo que no venía en el pegado | creado `Engine/FileEnumerator.cs` |
| `CS0428: método 'Count' como int` | `ScanPage.xaml.cs:102` | consecuencia del anterior (`ToList()` sobre un grupo de métodos) | resuelto al existir `FileEnumerator` |
| `CS0165: 'card' sin asignar` | `ShellPage.xaml.cs:195` | los botones de la tarjeta llamaban a `Close()`, que captura `card` y `timer` declarados más abajo | `Action dismiss` declarado antes y asignado al final; las 4 llamadas usan `dismiss()` |
| `CS0165: 'timer' sin asignar` | `ShellPage.xaml.cs:195` | ídem | ídem |

### Y dos del compilador de XAML

| Error | Archivo | Causa | Corrección |
|---|---|---|---|
| `WMC0001: Unknown type 'UniformGrid'` | `Views/LivePage.xaml:83` | `UniformGrid` **no existe en WinUI 3**: es un control de WPF (en WinUI viene en CommunityToolkit, no en el SDK) | sustituido por un `Grid` con 4 columnas `*` y `ColumnSpacing="12"`; cada tarjeta lleva su `Grid.Column` |
| `WMC0001: Unknown type 'UniformGrid'` | `Views/ScanPage.xaml:123` | ídem | ídem con `ColumnSpacing="24"` (los contadores del panel de análisis) |

### Y un crash en tiempo de ejecución

| Error | Causa | Corrección |
|---|---|---|
| `COMException: No COM servers are registered for this app` en `OnLaunched` | `AppNotificationManager.Default.Register()` necesita **identidad de paquete (MSIX)**. Ejecutando el `.exe` suelto o la configuración «sin empaquetar» de VS no existe el servidor COM de activación y la excepción no estaba capturada | `Register()` ahora prueba y, si falla, marca `ToastAvailable = false` y deja el aviso dentro de la ventana; el motivo se escribe en `%LocalAppData%\Aegis\app.log` |

### Diagnóstico de arranque (v5)

Ante un cierre silencioso con `0x80008089` (sin traza en el depurador), el arranque queda
instrumentado:

| Dónde | Qué hace |
|---|---|
| `App.App()` | suscribe `UnhandledException` y `AppDomain.UnhandledException`, y registra «App creada» |
| `App.OnLaunched()` | registra cada paso: notificaciones → `MainWindow` → `Activate`; si algo falla escribe el log y muestra un `MessageBox` nativo |
| `MainWindow` | la navegación a `LoginPage` pasa del constructor al evento `Loaded`, con `try/catch` y log |
| Log | `%LocalAppData%\Aegis\app.log` con fecha, paso, tipo de excepción, mensaje y `StackTrace` |

Con esto, cualquier fallo de arranque deja rastro en disco y en pantalla en lugar de
cerrar la app sin explicación.

### v8 — por qué «no aparecía nada»

| Causa | Corrección |
|---|---|
| `ScanPage.Record()` hacía `if (!item.IsAlert) return;`: los archivos limpios **no se listaban nunca**, así que parecía que no analizaba | ahora se listan **todos** los archivos analizados, con veredicto y puntuación; las alertas siguen disparando notificación |
| Los tres handlers (`ScanFile`, `ScanFolder`, `ScanZip`) eran `async void` con `try/finally` y **sin `catch`**: cualquier excepción (picker, permisos, ZIP dañado) desaparecía sin mensaje | añadido `catch` que escribe en `app.log` y muestra el error en `HeadTitle`/`HeadDetail` |
| No había forma de saber si se estaba ejecutando el build nuevo | el título de la ventana muestra **«motor 2.0»** y cada análisis se registra en `%LocalAppData%\Aegis\app.log` |

### Motor 2.0 — análisis estructural (v7)

El motor ya no solo mira bytes y cadenas: ahora entiende el formato.

| Inspector | Qué analiza | Ejemplos de indicios |
|---|---|---|
| `Engine/PeInspector.cs` | Cabecera PE, secciones, **tabla de importaciones**, overlay, entry point | `VirtualAllocEx` + `WriteProcessMemory` + `CreateRemoteThread` (inyección), `SetWindowsHookEx` (keylogger), `IsDebuggerPresent` (anti-debug), `URLDownloadToFile` (descarga), `CryptEncrypt` (ransomware), secciones `UPX0/Themida/.vmp0`, sección RWX, entropía ≥ 7,9 |
| `Engine/DocumentInspector.cs` | PDF, Office OOXML y accesos directos `.lnk` | `/JavaScript`, `/OpenAction`, `/Launch`; `word/vbaProject.bin` con `AutoOpen` + `CreateObject("WScript.Shell")`; `.lnk` con `powershell -enc` |
| `Engine/ArchiveInspector.cs` | ZIP sin extraer | entradas con `../` (zip slip), ejecutables dentro, bomba de descompresión, > 2 GB descomprimidos |

Resultados medidos con el proyecto compilado y muestras reales:

| Muestra | Veredicto | Score | Por qué |
|---|---|---|---|
| `7zr.exe` (binario legítimo real) | Limpio | 12 | 6 secciones, 133 imports, sin packer → **sin falso positivo** |
| `documento.exe` (texto renombrado) | Sospechoso | 38 | extensión ejecutable sin cabecera `MZ` |
| `eicar.txt` (firma de prueba) | Malicioso | 100 | firma EICAR dentro de un `.txt` |
| `presupuesto.pdf` con JS | Sospechoso | 50 | JavaScript + acción al abrir |
| `factura.lnk` → powershell -enc | Sospechoso | 67 | destino y argumentos de intérprete |
| `adjuntos.zip` con `../../evil.exe` | Sospechoso | 39 | zip slip + ejecutable dentro |
| `informe.docm` con macro AutoOpen | Sospechoso | 65 | macro con ejecución de comandos |
| PE con `VirtualAllocEx`+`WriteProcessMemory`+`CreateRemoteThread` | Malicioso | 73 | inyección de código en otro proceso |

### Motor: reglas anteriores (v6)

Detectado con pruebas reales: un `.txt` renombrado a `.exe` puntuaba **8/100** y se
marcaba «Limpio», así que nunca aparecía en la lista (la vista solo muestra alertas).

| Regla nueva | Puntos |
|---|---|
| Extensión ejecutable (`.exe`, `.dll`, `.scr`, `.com`…) sin cabecera `MZ` → archivo renombrado o dañado | +30 |
| Aviso «Análisis parcial: X MB revisados de Y MB» cuando el archivo supera el límite de lectura | informativo |

Resultados medidos tras el cambio:

| Muestra | Veredicto | Score |
|---|---|---|
| `documento.exe` (texto renombrado) | Sospechoso | 38 |
| `documento.txt.exe` | Sospechoso | 63 |
| `eicar.com` | Malicioso | 100 |
| `factura.pdf` con cabecera `MZ` | Sospechoso | 35 |
| `instalar.ps1` ofuscado | Sospechoso | 42 |

Umbrales: **≥ 35 sospechoso**, **≥ 70 malicioso** (`Models/ScanOptions.cs`).

Ningún cambio toca el diseño ni la lógica: el `Grid` de 4 columnas iguales reproduce el
reparto del `UniformGrid`, y la captura de `card`/`timer` se movió a una variable ya
inicializada.

## 5. Verificación hecha antes de entregar

| Comprobación | Resultado |
|---|---|
| Compilación C# (Roslyn, 16 archivos, refs reales WinUI 2.3.9 / SDK.NET 10.0.19041) | **0 errores** |
| Propiedades y eventos del XAML contra los metadatos de WinUI | **806 / 806 existen** |
| Tipos de control usados en el XAML | los 29 existen en WinUI 3 (ya sin `UniformGrid`) |
| Claves `{StaticResource ...}` frente a `App.xaml` | todas definidas (22) |
| `x:Bind` de las plantillas frente a `ScanItem` | todas resuelven |
| `x:Class` ↔ code-behind y `x:Name` duplicados | correctos en los 6 XAML |
| Firmas de los 19 handlers | todas coinciden con su `EventArgs` |
| `dotnet restore` de los paquetes 2.5.1 | correcto |

**No verificado** (necesita Windows): el paso del compilador de XAML (`.g.cs`), el
empaquetado MSIX y la ejecución.

## 6. Compilar

```powershell
dotnet build AntivirusApp.csproj -c Debug -p:Platform=x64
```

Abre `AntivirusApp.slnx` (VS 17.10+) o `AntivirusApp.sln` (cualquier VS 2022). Si algo
falla, genera el binlog y pásalo:

```powershell
dotnet build AntivirusApp.csproj -c Debug -p:Platform=x64 -bl:build.binlog
```

---

## v9 — Clenaer (nuevo módulo)

Se añade el **Clenaer** al menú lateral, entre *Análisis manual* y *Vigilancia en vivo*.
No se ha tocado ninguna línea de los módulos anteriores: el botón nuevo navega a
`CleanerPage` con el mismo `Navigate(...)` y el mismo `Mark(...)` de resaltado.

| Archivo nuevo | Qué contiene |
|---|---|
| `Views/CleanerPage.xaml` | Interfaz: tarjeta de unidades y opciones, progreso, filtros y lista |
| `Views/CleanerPage.xaml.cs` | Lógica de la vista (escaneo en segundo plano, orden, selección, papelera) |
| `Views/CleanerRow.cs` | Fila de la lista (sirve para archivos, carpetas y aplicaciones) |
| `Models/CleanerModels.cs` | `CleanerOptions`, `CleanerCounters`, `CleanerItem`, `AppUsage`, `TrashResult` |
| `Services/CleanerService.cs` | Motor: `Scan`, `MeasureApps`, `MoveToTrash`, `Reveal`, `DefaultRoots` |

| Archivo modificado | Cambio |
|---|---|
| `Views/ShellPage.xaml` | Botón `NavCleaner` («Clenaer», glifo de papelera) + pie «Motor heurístico 2.0 · Clenaer» |
| `Views/ShellPage.xaml.cs` | `NavCleaner_Click` y `Mark(NavCleaner, …)` en `Navigate` |

### Dos modos

1. **Archivos / Carpetas pesadas** — recorre las unidades con `DirectoryInfo` en un hilo
   de fondo (la UI nunca se bloquea) y devuelve lo que supera el mínimo elegido.
   Casilla **«Evitar carpetas de sistema»** activada por defecto: no entra en `Windows`,
   `System32`, `WinSxS`, `$Recycle.Bin`, `System Volume Information`, `$Windows.~BT`…
   Ordenable por **peso, nombre, fecha y tipo**; buscador; selección múltiple.
2. **Por aplicación** — mide cada carpeta de programa (`Program Files`, `Program Files (x86)`,
   `LocalAppData`, `Roaming`, `ProgramData`, Descargas, Documentos, Escritorio, Vídeos)
   y lista **peso, nº de archivos y última actividad**.

### Borrado

`SHFileOperationW` con `FOF_ALLOWUNDO` → **Papelera de reciclaje real de Windows**, sin
dependencias NuGet ni referencias a `Microsoft.VisualBasic`. Antes hay un `ContentDialog`
con la lista de elementos, el total a liberar y una casilla que hay que marcar para que
el botón se habilite. Lo que está en uso o sin permisos se informa y **no se borra**.

### Rendimiento

Un solo hilo para el escaneo, `Parallel.ForEach` (núcleos/2) para medir aplicaciones y un
`DispatcherQueueTimer` de 150 ms que refresca contadores: la ventana sigue respondiendo
incluso recorriendo un disco entero.
