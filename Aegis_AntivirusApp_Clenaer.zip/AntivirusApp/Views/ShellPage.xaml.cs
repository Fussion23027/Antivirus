using System;
using System.Diagnostics;
using AntivirusApp.Models;
using AntivirusApp.Services;
using Microsoft.UI.Text;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Media;

namespace AntivirusApp.Views;

public sealed partial class ShellPage : Page
{
    private const int ToastMilliseconds = 7000;
    private const int ToastLimit = 4;
    private ScanItem? _detail;

    public static ShellPage? Instance { get; private set; }

    public ShellPage()
    {
        InitializeComponent();
        Instance = this;
        NotificationService.InApp += m => DispatcherQueue.TryEnqueue(() => ShowToast(m));
        Loaded += ShellPage_Loaded;
    }

    private void ShellPage_Loaded(object sender, RoutedEventArgs e)
    {
        if (ContentFrame.Content is null)
        {
            Navigate(typeof(ScanPage), "Análisis manual", "Analiza archivos, carpetas o ZIP completos", NavScan);
        }
    }

    private void NavScan_Click(object sender, RoutedEventArgs e) =>
        Navigate(typeof(ScanPage), "Análisis manual", "Analiza archivos, carpetas o ZIP completos", NavScan);

    private void NavLive_Click(object sender, RoutedEventArgs e) =>
        Navigate(typeof(LivePage), "Vigilancia en vivo", "Revisa automáticamente cada archivo nuevo de Descargas", NavLive);

    private void NavCleaner_Click(object sender, RoutedEventArgs e) =>
        Navigate(typeof(CleanerPage), "Clenaer", "Encuentra lo que más pesa en el equipo y libéralo en un clic", NavCleaner);

    private void Navigate(Type page, string title, string subtitle, Button active)
    {
        if (ContentFrame.CurrentSourcePageType != page) ContentFrame.Navigate(page);
        TitleText.Text = title;
        SubText.Text = subtitle;
        Mark(NavScan, active == NavScan);
        Mark(NavCleaner, active == NavCleaner);
        Mark(NavLive, active == NavLive);
    }

    private static void Mark(Button button, bool on)
    {
        button.Background = on ? Palette.Of("RaisedBrush") : new SolidColorBrush(Microsoft.UI.Colors.Transparent);
        button.Foreground = on ? Palette.Of("TextBrush") : Palette.Of("MutedBrush");
    }

    public void OpenDetail(ScanItem item)
    {
        _detail = item;
        DrawerGlyph.Glyph = item.VerdictGlyph;
        DrawerGlyph.Foreground = item.Accent;
        DrawerState.Text = $"{item.VerdictLabel}, riesgo {item.Result.RiskScore} de 100";
        DrawerState.Foreground = item.Accent;
        DrawerName.Text = item.Name;
        DrOrigin.Text = item.Origin;
        DrType.Text = item.TypeText;
        DrSize.Text = item.SizeText;
        DrTime.Text = item.When.ToString("dd/MM/yyyy HH:mm:ss");
        DrSha.Text = item.Result.Sha256;
        ReasonsList.ItemsSource = item.Reasons;
        DeleteButton.IsEnabled = item.CanDelete;
        ShowButton.IsEnabled = true;
        Scrim.Visibility = Visibility.Visible;
        Drawer.Visibility = Visibility.Visible;
    }

    private void CloseDetail()
    {
        _detail = null;
        Scrim.Visibility = Visibility.Collapsed;
        Drawer.Visibility = Visibility.Collapsed;
    }

    private void CloseDetail_Click(object sender, RoutedEventArgs e) => CloseDetail();

    private void Scrim_Tapped(object sender, Microsoft.UI.Xaml.Input.TappedRoutedEventArgs e) => CloseDetail();

    private void ShowFolder_Click(object sender, RoutedEventArgs e) => _detail?.ShowInFolder();

    private async void Delete_Click(object sender, RoutedEventArgs e)
    {
        if (_detail is null) return;
        var item = _detail;

        var content = new StackPanel { Spacing = 12 };
        content.Children.Add(new TextBlock
        {
            Text = "Esta acción borra el archivo del disco y no se puede deshacer desde la aplicación.",
            TextWrapping = TextWrapping.Wrap,
            Foreground = Palette.Of("MutedBrush")
        });
        content.Children.Add(new Border
        {
            Background = Palette.Of("RaisedBrush"),
            CornerRadius = new CornerRadius(8),
            Padding = new Thickness(12),
            Child = new TextBlock
            {
                Text = item.FilePath,
                TextWrapping = TextWrapping.Wrap,
                FontFamily = new FontFamily("Consolas"),
                FontSize = 12
            }
        });

        var dialog = new ContentDialog
        {
            Title = "Eliminar archivo",
            Content = content,
            PrimaryButtonText = "Eliminar",
            CloseButtonText = "Cancelar",
            DefaultButton = ContentDialogButton.Close,
            XamlRoot = XamlRoot
        };

        if (await dialog.ShowAsync() != ContentDialogResult.Primary) return;

        try
        {
            item.Remove();
            CloseDetail();
            NotificationService.Summary("\uE73E", "Eliminado", "Archivo eliminado", item.Name, "OkBrush");
        }
        catch (Exception ex)
        {
            NotificationService.Summary("\uE783", "Error", "No se pudo eliminar el archivo", ex.Message, "DangerBrush");
        }
    }

    private void ShowToast(AlertMessage m)
    {
        var accent = Palette.Of(m.AccentKey);

        var tile = new Border
        {
            Width = 36,
            Height = 36,
            CornerRadius = new CornerRadius(9),
            Background = Palette.Of("PanelBrush"),
            Child = new FontIcon { Glyph = m.Glyph, FontSize = 16, Foreground = accent }
        };

        var bar = new ProgressBar
        {
            Maximum = 100,
            Value = 100,
            Height = 3,
            Foreground = accent,
            Margin = new Thickness(0, 8, 0, 0)
        };

        var text = new StackPanel { Spacing = 4 };
        text.Children.Add(new TextBlock
        {
            Text = m.Kind.ToUpperInvariant(),
            FontSize = 11,
            FontWeight = FontWeights.SemiBold,
            Foreground = accent
        });
        text.Children.Add(new TextBlock
        {
            Text = m.Title,
            FontSize = 14,
            FontWeight = FontWeights.SemiBold,
            TextWrapping = TextWrapping.Wrap
        });
        text.Children.Add(new TextBlock
        {
            Text = m.Body,
            FontSize = 12,
            Foreground = Palette.Of("MutedBrush"),
            TextWrapping = TextWrapping.Wrap
        });

        var ghost = (Style)Microsoft.UI.Xaml.Application.Current.Resources["GhostButton"];

        // Se declara aquí y se asigna al final: los botones lo usan antes de que
        // existan 'card' y 'timer' (si no, CS0165).
        Action dismiss = () => { };

        if (m.Item is not null)
        {
            var actions = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 8, Margin = new Thickness(0, 8, 0, 0) };
            var view = new Button { Content = "Ver detalle", Style = ghost, Padding = new Thickness(10, 5, 10, 5), FontSize = 12 };
            var folder = new Button { Content = "Mostrar carpeta", Style = ghost, Padding = new Thickness(10, 5, 10, 5), FontSize = 12 };
            actions.Children.Add(view);
            actions.Children.Add(folder);
            text.Children.Add(actions);
            view.Click += (_, _) => { OpenDetail(m.Item); dismiss(); };
            folder.Click += (_, _) => { m.Item.ShowInFolder(); dismiss(); };
        }

        text.Children.Add(bar);

        var close = new Button
        {
            Content = new FontIcon { Glyph = "\uE8BB", FontSize = 10 },
            Style = ghost,
            Padding = new Thickness(7),
            VerticalAlignment = VerticalAlignment.Top
        };

        var layout = new Grid { ColumnSpacing = 12 };
        layout.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        layout.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        layout.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        layout.Children.Add(tile);
        layout.Children.Add(text);
        layout.Children.Add(close);
        Grid.SetColumn(text, 1);
        Grid.SetColumn(close, 2);

        var card = new Border
        {
            Background = Palette.Of("RaisedBrush"),
            BorderBrush = Palette.Of("LineBrush"),
            BorderThickness = new Thickness(1),
            CornerRadius = new CornerRadius(12),
            Padding = new Thickness(14),
            Child = layout
        };

        ToastHost.Children.Add(card);
        while (ToastHost.Children.Count > ToastLimit) ToastHost.Children.RemoveAt(0);

        var watch = Stopwatch.StartNew();
        var timer = DispatcherQueue.CreateTimer();
        timer.Interval = TimeSpan.FromMilliseconds(40);

        dismiss = () =>
        {
            timer.Stop();
            ToastHost.Children.Remove(card);
        };

        timer.Tick += (_, _) =>
        {
            double left = 1 - watch.ElapsedMilliseconds / (double)ToastMilliseconds;
            if (left <= 0)
            {
                dismiss();
                return;
            }
            bar.Value = left * 100;
        };

        close.Click += (_, _) => dismiss();
        timer.Start();
    }

    private static T Prepare<T>(T value) where T : class => value;
}
