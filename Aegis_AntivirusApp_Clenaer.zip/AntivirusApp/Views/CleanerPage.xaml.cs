using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using AntivirusApp.Models;
using AntivirusApp.Services;
using Microsoft.UI.Dispatching;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Media;
using Windows.Storage.Pickers;
using WinRT.Interop;

namespace AntivirusApp.Views;

/// <summary>
/// Clenaer: busca lo que más pesa en el equipo (sin entrar en las carpetas de
/// sistema) y lo envía a la Papelera de reciclaje con confirmación.
///
/// Dos modos, igual que el resto de la app:
///   · Archivos / Carpetas pesadas  → lista ordenable por peso, nombre, fecha y tipo.
///   · Por aplicación               → peso, nº de archivos y última actividad de cada app.
/// </summary>
public sealed partial class CleanerPage : Page
{
    private enum Mode { Files, Folders, Apps }

    private readonly List<string> _roots = new();

    private CleanerScanResult _scan = new();
    private List<AppUsage> _apps = new();
    private CleanerCounters _counters = new();
    private CancellationTokenSource? _cts;
    private DispatcherQueueTimer? _pump;

    private Mode _mode = Mode.Files;
    private bool _descending = true;
    private bool _busy;

    public ObservableCollection<CleanerRow> Rows { get; } = new();

    public CleanerPage()
    {
        InitializeComponent();

        OrderButton.Content = "\u2193";  // descendente al arrancar
        _roots.AddRange(CleanerService.DefaultRoots());
        SyncRoots();
        SyncMode();
        SyncCounters();
        SetBusy(false);
        Rebuild();
    }

    // ------------------------------------------------------------------
    // Escaneo de archivos / carpetas
    // ------------------------------------------------------------------

    private async void Scan_Click(object sender, RoutedEventArgs e)
    {
        if (_busy) return;

        if (_roots.Count == 0)
        {
            HeadTitle.Text = "Elige una unidad o carpeta";
            HeadDetail.Text = "Pulsa «Añadir carpeta» para indicar qué se debe revisar.";
            return;
        }

        var options = new CleanerOptions(_roots.ToArray())
        {
            MinFileBytes = SelectedBytes(MinFileBox, 50L * 1024 * 1024),
            MinFolderBytes = SelectedBytes(MinFolderBox, 120L * 1024 * 1024),
            SkipSystem = SkipSystemBox.IsChecked == true,
            IncludeHidden = HiddenBox.IsChecked == true
        };

        _cts = new CancellationTokenSource();
        var token = _cts.Token;
        _counters = new CleanerCounters { Running = true, Current = "Preparando" };

        _scan = new CleanerScanResult();
        Rows.Clear();
        _mode = Mode.Files;
        SyncMode();

        HeadTitle.Text = "Escaneando…";
        HeadDetail.Text = string.Join("   ·   ", _roots);
        Bar.IsIndeterminate = true;
        SetBusy(true);
        StartPump();

        try
        {
            var counters = _counters;
            var result = await Task.Run(() => CleanerService.Scan(options, counters, token), token);

            _scan = result;
            Rebuild();

            string resumen = $"{counters.Files:N0} archivos revisados  ·  {CleanerService.FormatSize(counters.Bytes)} medidos  ·  {counters.Skipped:N0} carpetas de sistema omitidas";

            if (token.IsCancellationRequested)
            {
                HeadTitle.Text = "Escaneo detenido";
                HeadDetail.Text = "Se muestran los resultados encontrados hasta ese momento.";
            }
            else
            {
                HeadTitle.Text = result.Files.Count == 0
                    ? "No se encontraron archivos pesados"
                    : $"{result.Files.Count} archivos y {result.Folders.Count} carpetas pesadas";

                HeadDetail.Text = resumen;

                NotificationService.Summary("\uE721", "Clenaer", "Escaneo completado",
                    $"{result.Files.Count} archivos y {result.Folders.Count} carpetas superan el mínimo.", "AccentBrush");
            }
        }
        catch (OperationCanceledException)
        {
            HeadTitle.Text = "Escaneo detenido";
            HeadDetail.Text = "No se ha modificado nada en el equipo.";
        }
        catch (Exception ex)
        {
            App.Log("CleanerPage.Scan FALLÓ", ex);
            HeadTitle.Text = "No se pudo completar el escaneo";
            HeadDetail.Text = ex.GetType().Name + ": " + ex.Message;
        }
        finally
        {
            StopPump();
            Bar.IsIndeterminate = false;
            Bar.Value = 0;
            SyncCounters();
            SetBusy(false);
            _cts?.Dispose();
            _cts = null;
        }
    }

    private void Stop_Click(object sender, RoutedEventArgs e)
    {
        _cts?.Cancel();
        HeadDetail.Text = "Deteniendo el escaneo…";
    }

    // ------------------------------------------------------------------
    // Medición por aplicación
    // ------------------------------------------------------------------

    private async void Measure_Click(object sender, RoutedEventArgs e)
    {
        if (_busy) return;

        _cts = new CancellationTokenSource();
        var token = _cts.Token;
        _counters = new CleanerCounters { Running = true, Current = "Buscando aplicaciones" };

        _mode = Mode.Apps;
        SyncMode();

        HeadTitle.Text = "Midiendo aplicaciones…";
        HeadDetail.Text = "Calculando el peso real de cada carpeta de programa.";
        Bar.IsIndeterminate = true;
        SetBusy(true);
        StartPump();

        try
        {
            var counters = _counters;
            var apps = await Task.Run(() => CleanerService.MeasureApps(counters, token), token);

            _apps = apps;
            Rebuild();

            long total = apps.Sum(a => a.Size);
            HeadTitle.Text = apps.Count == 0 ? "No se pudieron medir aplicaciones" : $"{apps.Count} aplicaciones medidas";
            HeadDetail.Text = $"Peso total {CleanerService.FormatSize(total)}  ·  la mayor ocupa {CleanerService.FormatSize(apps.Count > 0 ? apps[0].Size : 0)}";

            NotificationService.Summary("\uE71D", "Clenaer", "Aplicaciones medidas",
                $"{apps.Count} aplicaciones, {CleanerService.FormatSize(total)} en total.", "AccentBrush");
        }
        catch (OperationCanceledException)
        {
            HeadTitle.Text = "Medición detenida";
        }
        catch (Exception ex)
        {
            App.Log("CleanerPage.Measure FALLÓ", ex);
            HeadTitle.Text = "No se pudieron medir las aplicaciones";
            HeadDetail.Text = ex.GetType().Name + ": " + ex.Message;
        }
        finally
        {
            StopPump();
            Bar.IsIndeterminate = false;
            Bar.Value = 0;
            SyncCounters();
            SetBusy(false);
            _cts?.Dispose();
            _cts = null;
        }
    }

    // ------------------------------------------------------------------
    // Unidades
    // ------------------------------------------------------------------

    private async void AddFolder_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var picker = Prepare(new FolderPicker());
            picker.FileTypeFilter.Add("*");

            var folder = await picker.PickSingleFolderAsync();
            if (folder is null) return;

            if (!_roots.Contains(folder.Path, StringComparer.OrdinalIgnoreCase))
            {
                _roots.Add(folder.Path);
                SyncRoots();
            }
        }
        catch (Exception ex)
        {
            App.Log("CleanerPage.AddFolder FALLÓ", ex);
        }
    }

    private void ResetRoots_Click(object sender, RoutedEventArgs e)
    {
        _roots.Clear();
        _roots.AddRange(CleanerService.DefaultRoots());
        SyncRoots();
    }

    private void SyncRoots()
    {
        RootText.Text = _roots.Count == 0
            ? "Sin unidades seleccionadas"
            : string.Join("   ·   ", _roots);
    }

    // ------------------------------------------------------------------
    // Filtros y orden
    // ------------------------------------------------------------------

    private void Chip_Click(object sender, RoutedEventArgs e)
    {
        if (ReferenceEquals(sender, ChipFiles)) _mode = Mode.Files;
        else if (ReferenceEquals(sender, ChipFolders)) _mode = Mode.Folders;
        else _mode = Mode.Apps;

        SyncMode();
        Rebuild();
    }

    private void Search_TextChanged(object sender, TextChangedEventArgs e) => Rebuild();

    private void Sort_Changed(object sender, SelectionChangedEventArgs e) => Rebuild();

    private void Order_Click(object sender, RoutedEventArgs e)
    {
        _descending = !_descending;
        OrderButton.Content = _descending ? "\u2193" : "\u2191";
        Rebuild();
    }

    private void Rebuild()
    {
        IEnumerable<CleanerRow> source;

        if (_mode == Mode.Apps) source = _apps.Select(CleanerRow.FromApp);
        else if (_mode == Mode.Folders) source = _scan.Folders.Select(CleanerRow.FromItem);
        else source = _scan.Files.Select(CleanerRow.FromItem);

        var query = SearchBox.Text.Trim();
        if (query.Length > 0)
        {
            source = source.Where(r =>
                r.Name.Contains(query, StringComparison.OrdinalIgnoreCase) ||
                r.Path.Contains(query, StringComparison.OrdinalIgnoreCase) ||
                r.Sub.Contains(query, StringComparison.OrdinalIgnoreCase) ||
                r.KindText.Contains(query, StringComparison.OrdinalIgnoreCase));
        }

        var list = Sort(source);

        Rows.Clear();
        foreach (var row in list) Rows.Add(row);

        CountText.Text = $"{Rows.Count} elementos";
        UpdateSelection();
    }

    private List<CleanerRow> Sort(IEnumerable<CleanerRow> source)
    {
        int index = SortBox is null ? 0 : SortBox.SelectedIndex;

        IOrderedEnumerable<CleanerRow> ordered = index switch
        {
            1 => _descending
                    ? source.OrderByDescending(r => r.Name, StringComparer.OrdinalIgnoreCase)
                    : source.OrderBy(r => r.Name, StringComparer.OrdinalIgnoreCase),
            2 => _descending
                    ? source.OrderByDescending(r => r.Modified)
                    : source.OrderBy(r => r.Modified),
            3 => _descending
                    ? source.OrderByDescending(r => r.KindText, StringComparer.OrdinalIgnoreCase).ThenByDescending(r => r.Size)
                    : source.OrderBy(r => r.KindText, StringComparer.OrdinalIgnoreCase).ThenByDescending(r => r.Size),
            _ => _descending
                    ? source.OrderByDescending(r => r.Size)
                    : source.OrderBy(r => r.Size)
        };

        return ordered.ToList();
    }

    // ------------------------------------------------------------------
    // Selección
    // ------------------------------------------------------------------

    private void RowList_SelectionChanged(object sender, SelectionChangedEventArgs e) => UpdateSelection();

    private void SelectAll_Click(object sender, RoutedEventArgs e)
    {
        RowList.SelectAll();
        UpdateSelection();
    }

    private void Clear_Click(object sender, RoutedEventArgs e)
    {
        RowList.SelectedItems.Clear();
        UpdateSelection();
    }

    private void UpdateSelection()
    {
        long total = 0;
        int count = 0;

        foreach (var item in RowList.SelectedItems)
        {
            if (item is CleanerRow row)
            {
                total += row.Size;
                count++;
            }
        }

        SelectedText.Text = count == 0
            ? "0 B seleccionados"
            : $"{count} elementos  ·  {CleanerService.FormatSize(total)}";

        KSelected.Text = CleanerService.FormatSize(total);
        DeleteButton.IsEnabled = count > 0 && !_busy;
        RevealButton.IsEnabled = count == 1 && !_busy;
    }

    private void Reveal_Click(object sender, RoutedEventArgs e)
    {
        if (RowList.SelectedItems.Count != 1) return;
        if (RowList.SelectedItems[0] is CleanerRow row) CleanerService.Reveal(row.Path);
    }

    // ------------------------------------------------------------------
    // Enviar a la papelera
    // ------------------------------------------------------------------

    private async void Delete_Click(object sender, RoutedEventArgs e)
    {
        var selected = RowList.SelectedItems.OfType<CleanerRow>().ToList();
        if (selected.Count == 0) return;

        long total = selected.Sum(r => r.Size);
        bool apps = _mode == Mode.Apps;

        var content = new StackPanel { Spacing = 12 };

        content.Children.Add(new TextBlock
        {
            Text = apps
                ? "Se moverán carpetas completas de programa a la Papelera de reciclaje. La aplicación dejará de funcionar hasta que la restaures."
                : "Se moverán a la Papelera de reciclaje. Puedes recuperarlos desde ella si te equivocas.",
            TextWrapping = TextWrapping.Wrap,
            Foreground = Palette.Of("MutedBrush")
        });

        var boxList = new StackPanel { Spacing = 6 };

        var box = new Border
        {
            Background = Palette.Of("RaisedBrush"),
            CornerRadius = new CornerRadius(8),
            Padding = new Thickness(12),
            Child = boxList
        };

        foreach (var row in selected.Take(8))
        {
            var line = new Grid { ColumnSpacing = 10 };
            line.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            line.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            var label = new TextBlock
            {
                Text = row.Name,
                FontSize = 12,
                TextTrimming = TextTrimming.CharacterEllipsis
            };
            var size = new TextBlock
            {
                Text = row.SizeText,
                FontSize = 12,
                FontWeight = Microsoft.UI.Text.FontWeights.SemiBold
            };

            line.Children.Add(label);
            line.Children.Add(size);
            Grid.SetColumn(size, 1);
            boxList.Children.Add(line);
        }

        content.Children.Add(box);

        content.Children.Add(new TextBlock
        {
            Text = $"{selected.Count} elemento(s)  ·  {CleanerService.FormatSize(total)}",
            FontSize = 12,
            Foreground = Palette.Of("MutedBrush")
        });

        var confirm = new CheckBox { Content = "Entiendo que se moverán a la Papelera de reciclaje" };

        content.Children.Add(confirm);

        var dialog = new ContentDialog
        {
            Title = "Enviar a la papelera",
            Content = content,
            PrimaryButtonText = "Enviar a la papelera",
            CloseButtonText = "Cancelar",
            DefaultButton = ContentDialogButton.Close,
            IsPrimaryButtonEnabled = false,
            XamlRoot = XamlRoot
        };

        confirm.Checked += (_, _) => dialog.IsPrimaryButtonEnabled = true;
        confirm.Unchecked += (_, _) => dialog.IsPrimaryButtonEnabled = false;

        if (await dialog.ShowAsync() != ContentDialogResult.Primary) return;

        var paths = selected.Select(r => r.Path).ToList();

        SetBusy(true);
        try
        {
            var result = await Task.Run(() => CleanerService.MoveToTrash(paths));
            var moved = new HashSet<string>(result.Moved, StringComparer.OrdinalIgnoreCase);

            if (apps)
            {
                _apps = _apps.Where(a => !moved.Contains(a.Path)).ToList();
            }
            else
            {
                _scan.Files.RemoveAll(f => moved.Contains(f.Path));
                _scan.Folders.RemoveAll(f => moved.Contains(f.Path));
            }

            RowList.SelectedItems.Clear();
            Rebuild();

            if (result.Moved.Count > 0)
            {
                NotificationService.Summary("\uE73E", "Clenaer", "Papelera",
                    $"{result.Moved.Count} elemento(s) enviados  ·  {CleanerService.FormatSize(result.Freed)} liberados", "OkBrush");
            }

            if (result.Failed.Count > 0)
            {
                NotificationService.Summary("\uE783", "Clenaer", "No se pudieron mover todos",
                    $"{result.Failed.Count} elemento(s) en uso o sin permisos siguen en su sitio.", "DangerBrush");
            }

            HeadTitle.Text = $"{result.Moved.Count} elemento(s) a la papelera";
            HeadDetail.Text = $"Se liberaron {CleanerService.FormatSize(result.Freed)}";
        }
        catch (Exception ex)
        {
            App.Log("CleanerPage.Delete FALLÓ", ex);
            NotificationService.Summary("\uE783", "Clenaer", "Error al mover a la papelera",
                ex.GetType().Name + ": " + ex.Message, "DangerBrush");
        }
        finally
        {
            SetBusy(false);
        }
    }

    // ------------------------------------------------------------------
    // Estado de la interfaz
    // ------------------------------------------------------------------

    private void StartPump()
    {
        _pump = DispatcherQueue.CreateTimer();
        _pump.Interval = TimeSpan.FromMilliseconds(150);
        _pump.Tick += (_, _) => SyncCounters();
        _pump.Start();
    }

    private void StopPump()
    {
        _pump?.Stop();
        _pump = null;
    }

    private void SyncCounters()
    {
        var counters = _counters;

        KFiles.Text = counters.Files.ToString("N0");
        KDirs.Text = counters.Dirs.ToString("N0");
        KBytes.Text = CleanerService.FormatSize(counters.Bytes);

        if (counters.Running)
        {
            HeadDetail.Text = string.IsNullOrEmpty(counters.Current)
                ? "Recorriendo…"
                : counters.Current;
        }
    }

    private void SyncMode()
    {
        Mark(ChipFiles, _mode == Mode.Files);
        Mark(ChipFolders, _mode == Mode.Folders);
        Mark(ChipApps, _mode == Mode.Apps);

        MeasureButton.IsEnabled = !_busy;
        MinFileBox.IsEnabled = !_busy;
        MinFolderBox.IsEnabled = !_busy;
        SearchBox.IsEnabled = true;
    }

    private void SetBusy(bool busy)
    {
        _busy = busy;
        ScanButton.IsEnabled = !busy;
        StopButton.IsEnabled = busy;
        MeasureButton.IsEnabled = !busy;
        MinFileBox.IsEnabled = !busy;
        MinFolderBox.IsEnabled = !busy;
        SkipSystemBox.IsEnabled = !busy;
        HiddenBox.IsEnabled = !busy;
        UpdateSelection();
    }

    private static void Mark(Button button, bool on)
    {
        button.Background = on ? Palette.Of("RaisedBrush") : new SolidColorBrush(Microsoft.UI.Colors.Transparent);
        button.Foreground = on ? Palette.Of("TextBrush") : Palette.Of("MutedBrush");
    }

    private static long SelectedBytes(ComboBox box, long fallback)
    {
        if (box.SelectedItem is ComboBoxItem item &&
            item.Tag is string tag &&
            long.TryParse(tag, out var value))
        {
            return value;
        }

        return fallback;
    }

    private static T Prepare<T>(T picker) where T : class
    {
        InitializeWithWindow.Initialize(picker, WindowNative.GetWindowHandle(App.CurrentWindow));
        return picker;
    }
}
