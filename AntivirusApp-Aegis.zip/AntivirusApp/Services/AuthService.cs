using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace AntivirusApp.Services;

/// <summary>
/// Autenticación local de la demo.
///
/// Credenciales por defecto: usuario <c>admin</c> / contraseña <c>aegis</c>.
/// Se pueden cambiar creando <c>%LocalAppData%\Aegis\auth.json</c>:
///
/// <code>
/// { "user": "miUsuario", "sha256": "HASH_DE_LA_CONTRASEÑA_EN_HEX" }
/// </code>
///
/// No se guarda nunca la contraseña en claro y la comparación es en tiempo fijo.
/// </summary>
public static class AuthService
{
    private const string DefaultUser = "admin";

    private static readonly string Folder =
        Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "Aegis");

    private static string File_ => Path.Combine(Folder, "auth.json");

    public static bool Validate(string user, string password)
    {
        if (string.IsNullOrWhiteSpace(user) || string.IsNullOrEmpty(password))
        {
            return false;
        }

        (string expectedUser, string expectedHash) = Load();

        if (!string.Equals(user, expectedUser, StringComparison.OrdinalIgnoreCase))
        {
            return false;
        }

        string hash = Hash(password);

        return FixedTimeEquals(hash, expectedHash);
    }

    private static (string User, string Hash) Load()
    {
        try
        {
            if (!File.Exists(File_))
            {
                return (DefaultUser, Hash("aegis"));
            }

            var doc = JsonSerializer.Deserialize<AuthFile>(File.ReadAllText(File_, Encoding.UTF8));

            if (doc is null || string.IsNullOrWhiteSpace(doc.User) || string.IsNullOrWhiteSpace(doc.Sha256))
            {
                return (DefaultUser, Hash("aegis"));
            }

            return (doc.User, doc.Sha256.Trim().ToLowerInvariant());
        }
        catch (Exception)
        {
            return (DefaultUser, Hash("aegis"));
        }
    }

    private static string Hash(string value) =>
        Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(value))).ToLowerInvariant();

    private static bool FixedTimeEquals(string left, string right)
    {
        byte[] a = Encoding.UTF8.GetBytes(left);
        byte[] b = Encoding.UTF8.GetBytes(right);

        return a.Length == b.Length && CryptographicOperations.FixedTimeEquals(a, b);
    }

    private sealed class AuthFile
    {
        public string User { get; set; } = "";

        public string Sha256 { get; set; } = "";
    }
}
