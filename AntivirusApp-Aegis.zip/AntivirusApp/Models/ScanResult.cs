using System;
using System.Collections.Generic;

namespace AntivirusApp.Models;

/// <summary>
/// Resultado de un análisis. Se usan setters públicos (no <c>init</c>) porque
/// el generador de tipos XAML de WinUI crea los accesores de escritura de forma
/// automática y con <c>init</c> el build falla con CS8852 en XamlTypeInfo.g.cs.
/// </summary>
public sealed class ScanResult
{
    /// <summary>Uno de los valores de <see cref="Verdicts"/>.</summary>
    public string Verdict { get; set; } = Verdicts.Clean;

    /// <summary>Riesgo 0-100.</summary>
    public int RiskScore { get; set; }

    /// <summary>Motivos encontrados, en texto legible.</summary>
    public IReadOnlyList<string> Reasons { get; set; } = Array.Empty<string>();

    /// <summary>SHA-256 del archivo analizado (vacío si no se pudo leer).</summary>
    public string Sha256 { get; set; } = "";

    public long Size { get; set; }

    public TimeSpan Elapsed { get; set; }

    /// <summary>True si el archivo no se pudo leer (permisos, bloqueo...).</summary>
    public bool IsError { get; set; }
}
